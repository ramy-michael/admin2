<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Returnsale extends Model
{
  public $table = "returns";

    protected $guarded = [];
}
